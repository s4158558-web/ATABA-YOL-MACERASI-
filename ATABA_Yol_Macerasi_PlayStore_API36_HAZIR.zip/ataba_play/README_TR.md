# ATABA Yol Macerası — Android paket projesi

Bu proje, yüklenen ATABA Yol Macerası v99 HTML oyununu Android WebView içine paketler.

## APK oluşturma
1. Bu klasörü Android Studio ile aç.
2. Gradle senkronizasyonunu bekle.
3. `app` > `Build` > `Build APK(s)` seç.
4. APK `app/build/outputs/apk/` altında oluşur.

Oyun dosyası `app/src/main/assets/index.html` içindedir.

Not: Bu ortamda Android SDK/Gradle derleyicisi bulunmadığı için burada doğrudan imzalı APK derlenemedi; proje derlemeye hazır kaynak olarak hazırlanmıştır.


NOT: Bu KAPAKLI TEST sürümünün applicationId'si com.ataba.yolmacera.kapakli olarak ayarlanmıştır. Eski com.ataba.yolmacera uygulamasıyla çakışmadan yan yana kurulabilir. Google Play için nihai sürümde ana applicationId kullanılmalıdır.


Play Store hazırlığı: compileSdk/targetSdk 36, AGP 8.9.1, versionCode 101, versionName 1.0.1. Release build minify kapalıdır. Google Play için son AAB, Play Console'un imzalama süreciyle imzalanmalıdır.
