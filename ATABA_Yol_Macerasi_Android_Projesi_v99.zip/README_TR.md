# ATABA Yol Macerası — Android paket projesi

Bu proje, yüklenen ATABA Yol Macerası v99 HTML oyununu Android WebView içine paketler.

## APK oluşturma
1. Bu klasörü Android Studio ile aç.
2. Gradle senkronizasyonunu bekle.
3. `app` > `Build` > `Build APK(s)` seç.
4. APK `app/build/outputs/apk/` altında oluşur.

Oyun dosyası `app/src/main/assets/index.html` içindedir.

Not: Bu ortamda Android SDK/Gradle derleyicisi bulunmadığı için burada doğrudan imzalı APK derlenemedi; proje derlemeye hazır kaynak olarak hazırlanmıştır.
